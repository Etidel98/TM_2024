# TM_2024
'''
This public Github repository was created in order to give public access to all pre-processing data, 
files, codes I used in the context of my master thesis 2024 dedicated to hydrological modelling 
using the SWAT model.
'''

In this repository, you will have access to the files necessary to complete understanding of 
SWAT-specific knowledge as well as methodology. Feel free to roam around!
